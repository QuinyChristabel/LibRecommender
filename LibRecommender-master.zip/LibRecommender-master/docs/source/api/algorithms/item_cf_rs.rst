RsItemCF
--------

.. autoclass:: libreco.algorithms.RsItemCF
   :members:
   :inherited-members:
   :show-inheritance:
