Caser
-----

.. autoclass:: libreco.algorithms.Caser
   :members:
   :inherited-members:
   :show-inheritance:
