UserCF
------

.. autoclass:: libreco.algorithms.UserCF
   :members:
   :inherited-members:
   :show-inheritance:
