Base Classes
------------

.. autoclass:: libreco.bases.Base
   :members:
   :inherited-members:
   :show-inheritance:

.. autoclass:: libreco.bases.EmbedBase
   :members:
   :inherited-members:
   :show-inheritance:

.. autoclass:: libreco.bases.TfBase
   :members:
   :inherited-members:
   :show-inheritance:

.. autoclass:: libreco.bases.CfBase
   :members:
   :inherited-members:
   :show-inheritance:

.. autoclass:: libreco.bases.RsCfBase
   :members:
   :inherited-members:
   :show-inheritance:

.. autoclass:: libreco.bases.GensimBase
   :members:
   :inherited-members:
   :show-inheritance:

.. autoclass:: libreco.bases.SageBase
   :members:
   :inherited-members:
   :show-inheritance:

.. autoclass:: libreco.bases.DynEmbedBase
   :members:
   :inherited-members:
   :show-inheritance:
