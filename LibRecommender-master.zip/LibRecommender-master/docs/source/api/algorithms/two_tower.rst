TwoTower
--------

.. autoclass:: libreco.algorithms.TwoTower
   :members:
   :inherited-members:
   :show-inheritance:
