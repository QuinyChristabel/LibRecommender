SVD++
-----

.. autoclass:: libreco.algorithms.SVDpp
   :members:
   :inherited-members:
   :show-inheritance:
