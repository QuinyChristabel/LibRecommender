PinSage
-------

.. autoclass:: libreco.algorithms.PinSage
   :members:
   :inherited-members:
   :show-inheritance:
