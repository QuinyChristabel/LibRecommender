GraphSageDGL
------------

.. autoclass:: libreco.algorithms.GraphSageDGL
   :members:
   :inherited-members:
   :show-inheritance:
   :exclude-members: transform_blocks
