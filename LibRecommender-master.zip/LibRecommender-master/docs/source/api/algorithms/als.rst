ALS
---

.. autoclass:: libreco.algorithms.ALS
   :members:
   :inherited-members:
   :show-inheritance:
