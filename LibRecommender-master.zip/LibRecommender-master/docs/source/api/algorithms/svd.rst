SVD
---

.. autoclass:: libreco.algorithms.SVD
   :members:
   :inherited-members:
   :show-inheritance:
