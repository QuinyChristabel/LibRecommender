GraphSage
---------

.. autoclass:: libreco.algorithms.GraphSage
   :members:
   :inherited-members:
   :show-inheritance:
