Swing
-----

.. autoclass:: libreco.algorithms.Swing
   :members:
   :inherited-members:
   :show-inheritance:
