SIM
---

.. autoclass:: libreco.algorithms.SIM
   :members:
   :inherited-members:
   :show-inheritance:
