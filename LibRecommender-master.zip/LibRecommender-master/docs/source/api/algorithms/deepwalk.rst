DeepWalk
--------

.. autoclass:: libreco.algorithms.DeepWalk
   :members:
   :inherited-members:
   :show-inheritance:
