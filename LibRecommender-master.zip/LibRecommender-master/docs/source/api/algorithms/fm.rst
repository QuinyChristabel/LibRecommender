FM
--

.. autoclass:: libreco.algorithms.FM
   :members:
   :inherited-members:
   :show-inheritance:
