NCF
---

.. autoclass:: libreco.algorithms.NCF
   :members:
   :inherited-members:
   :show-inheritance:
