LightGCN
--------

.. autoclass:: libreco.algorithms.LightGCN
   :members:
   :inherited-members:
   :show-inheritance:
