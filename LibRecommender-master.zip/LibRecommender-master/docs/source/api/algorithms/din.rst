DIN
---

.. autoclass:: libreco.algorithms.DIN
   :members:
   :inherited-members:
   :show-inheritance:
