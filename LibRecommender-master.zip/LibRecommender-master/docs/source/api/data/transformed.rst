TransformedSet
==============

.. autoclass:: libreco.data.TransformedSet
   :members:
   :special-members: __len__

.. autoclass:: libreco.data.TransformedEvalSet
   :members:
   :special-members: __len__
