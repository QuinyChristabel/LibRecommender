# RecFarm

Rust implementation for some non-deep learning recommender algorithms.

## Installation

```shell
$ pip install recfarm
```

Requires Python >= 3.7.
