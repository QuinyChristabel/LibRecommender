Evaluation
==========

.. automodule:: libreco.evaluation
    :members:
