Serialization
=============

.. autofunction:: libserving.serialization.save_knn

.. autofunction:: libserving.serialization.save_embed

.. autofunction:: libserving.serialization.save_tf

.. autofunction:: libserving.serialization.save_online

.. autofunction:: libserving.serialization.knn2redis

.. autofunction:: libserving.serialization.embed2redis

.. autofunction:: libserving.serialization.tf2redis

.. autofunction:: libserving.serialization.online2redis
