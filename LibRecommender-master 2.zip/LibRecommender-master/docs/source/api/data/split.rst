Split
=====

.. autofunction:: libreco.data.random_split

.. autofunction:: libreco.data.split_by_ratio

.. autofunction:: libreco.data.split_by_num

.. autofunction:: libreco.data.split_by_ratio_chrono

.. autofunction:: libreco.data.split_by_num_chrono

.. autofunction:: libreco.data.split_multi_value
