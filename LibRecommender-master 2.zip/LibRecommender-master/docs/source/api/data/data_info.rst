DataInfo
========

.. autoclass:: libreco.data.DataInfo
   :members:
   :special-members: __repr__

.. autoclass:: libreco.data.MultiSparseInfo
