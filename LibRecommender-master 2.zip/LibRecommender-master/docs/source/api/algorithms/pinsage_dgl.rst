PinSageDGL
----------

.. autoclass:: libreco.algorithms.PinSageDGL
   :members:
   :inherited-members:
   :show-inheritance:
   :exclude-members: transform_blocks
