Item2Vec
--------

.. autoclass:: libreco.algorithms.Item2Vec
   :members:
   :inherited-members:
   :show-inheritance:
