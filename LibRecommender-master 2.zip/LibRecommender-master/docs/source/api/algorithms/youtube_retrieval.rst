YouTubeRetrieval
----------------

.. autoclass:: libreco.algorithms.YouTubeRetrieval
   :members:
   :inherited-members:
   :show-inheritance:
