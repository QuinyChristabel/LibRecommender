ItemCF
------

.. autoclass:: libreco.algorithms.ItemCF
   :members:
   :inherited-members:
   :show-inheritance:
