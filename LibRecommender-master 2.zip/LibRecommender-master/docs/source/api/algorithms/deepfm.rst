DeepFM
------

.. autoclass:: libreco.algorithms.DeepFM
   :members:
   :inherited-members:
   :show-inheritance:
