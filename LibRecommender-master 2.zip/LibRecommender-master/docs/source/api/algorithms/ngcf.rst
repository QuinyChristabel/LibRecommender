NGCF
----

.. autoclass:: libreco.algorithms.NGCF
   :members:
   :inherited-members:
   :show-inheritance:
