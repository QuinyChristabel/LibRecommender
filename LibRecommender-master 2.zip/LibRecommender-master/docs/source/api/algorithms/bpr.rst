BPR
---

.. autoclass:: libreco.algorithms.BPR
   :members:
   :inherited-members:
   :show-inheritance:
