YouTubeRanking
--------------

.. autoclass:: libreco.algorithms.YouTubeRanking
   :members:
   :inherited-members:
   :show-inheritance:
