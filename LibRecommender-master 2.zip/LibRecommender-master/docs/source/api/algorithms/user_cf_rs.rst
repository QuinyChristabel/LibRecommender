RsUserCF
--------

.. autoclass:: libreco.algorithms.RsUserCF
   :members:
   :inherited-members:
   :show-inheritance:
