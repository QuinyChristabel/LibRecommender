AutoInt
-------

.. autoclass:: libreco.algorithms.AutoInt
   :members:
   :inherited-members:
   :show-inheritance:
