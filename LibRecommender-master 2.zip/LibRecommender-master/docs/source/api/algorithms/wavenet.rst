WaveNet
-------

.. autoclass:: libreco.algorithms.WaveNet
   :members:
   :inherited-members:
   :show-inheritance:
