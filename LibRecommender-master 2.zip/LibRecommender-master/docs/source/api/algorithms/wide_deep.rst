Wide & Deep
-----------

.. autoclass:: libreco.algorithms.WideDeep
   :members:
   :inherited-members:
   :show-inheritance:
