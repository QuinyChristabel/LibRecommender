RNN4Rec
-------

.. autoclass:: libreco.algorithms.RNN4Rec
   :members:
   :inherited-members:
   :show-inheritance:
