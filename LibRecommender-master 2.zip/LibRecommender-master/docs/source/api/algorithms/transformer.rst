Transformer
-----------

.. autoclass:: libreco.algorithms.Transformer
   :members:
   :inherited-members:
   :show-inheritance:
